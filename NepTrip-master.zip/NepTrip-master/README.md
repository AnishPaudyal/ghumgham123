# NepTrip

A desktop application which provides you good details about the tourism places in Nepal. It is built using *Qt framework*. 

Team Members : (*A team of enthusiastic programming beginners*) <br>
**Aseem Regmi** <br>
**Niranjan Pant** <br>
**Aashish Dhakal**

**Screenshots of our application** <br>
![Home Page](https://github.com/aseemregmi/NepTrip/blob/master/homePage.jpg "Home Page")

![Map Screen](https://github.com/aseemregmi/NepTrip/blob/master/mapPage.jpg "Map Screen")

![About](https://github.com/aseemregmi/NepTrip/blob/master/aboutPage.jpg "About")

![Details Screen](https://github.com/aseemregmi/NepTrip/blob/master/detailScreen.jpg "Details Screen")


